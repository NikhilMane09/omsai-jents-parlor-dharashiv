# OmSai Jents Parlor Dharashiv — Play Store Listing

App name:
OmSai Jents Parlor Dharashiv

Short description:
Salon customer management and visit reminder app for OmSai Jents Parlor Dharashiv.

Full description:
OmSai Jents Parlor Dharashiv is a simple customer-management app for the salon.
Save customer names and mobile numbers, keep a customer list, and use the app to manage regular haircut and beard-visit reminders.

Current project features:
- Add customer name
- Save mobile number
- View customer list
- Delete customer records
- Salon-branded app name

Important:
Automatic reminders sent to a customer's phone require a customer-side app or a server/SMS/WhatsApp notification service. A salon-only app cannot silently send push notifications to another person's phone without such a service and the customer's consent.
