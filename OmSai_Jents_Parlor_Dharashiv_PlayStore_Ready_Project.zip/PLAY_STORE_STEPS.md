# Play Store publishing steps

1. Create/sign in to a Google Play Console developer account.
2. Complete developer identity verification.
3. Create the app:
   - Name: OmSai Jents Parlor Dharashiv
   - App: App
   - Free
4. Complete the store listing, app content, data safety and privacy policy sections.
5. Build and upload the signed Android App Bundle (.aab).
6. For a new personal developer account created after 13 Nov 2023, run a closed test with at least 12 opted-in testers continuously for 14 days, then apply for production access.
7. Fix any review errors/warnings, submit the production release, and wait for Google review.
8. After approval, the app becomes available on Google Play in the selected countries/regions.

This project is source code. A signed AAB must be built in Android Studio/Gradle and signed with your release key before upload.
