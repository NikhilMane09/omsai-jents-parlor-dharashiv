package com.omsaijentsparlor.dharashiv;
import android.app.*; import android.os.*; import android.content.*; import android.graphics.Color; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 LinearLayout list; android.content.SharedPreferences sp;
 public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("customers",0); build();}
 TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(20,20,20,20);return v;}
 void build(){ LinearLayout main=new LinearLayout(this);main.setOrientation(LinearLayout.VERTICAL);main.setPadding(20,20,20,20);
 TextView title=t("OmSai Jents Parlor Dharashiv",24); title.setTextColor(Color.BLACK);main.addView(title);
 TextView sub=t("Customer Reminder App",16);main.addView(sub);
 Button add=new Button(this);add.setText("＋ ग्राहक Add करा");add.setOnClickListener(v->dialog());main.addView(add);
 list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this);sv.addView(list);main.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(main);refresh();}
 void dialog(){ final LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(30,5,30,5);
 EditText n=new EditText(this);n.setHint("ग्राहकाचे नाव");x.addView(n); EditText p=new EditText(this);p.setHint("मोबाईल नंबर");p.setInputType(2);x.addView(p);
 new AlertDialog.Builder(this).setTitle("नवीन ग्राहक").setView(x).setPositiveButton("Save",(d,w)->{sp.edit().putString(p.getText().toString(),n.getText().toString()).apply();refresh();}).setNegativeButton("Cancel",null).show();}
 void refresh(){list.removeAllViews(); for(String k:sp.getAll().keySet()){String n=sp.getString(k,""); LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
 TextView v=t(n+"\n"+k+"\nदर महिन्याला कटिंग/दाढीसाठी रिमाइंडर",16);row.addView(v,new LinearLayout.LayoutParams(0,-2,1));
 Button del=new Button(this);del.setText("Delete");del.setOnClickListener(x-> {sp.edit().remove(k).apply();refresh();});row.addView(del);list.addView(row);}}
}