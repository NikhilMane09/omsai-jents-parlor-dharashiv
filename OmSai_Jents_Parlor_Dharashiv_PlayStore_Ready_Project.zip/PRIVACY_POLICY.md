# Privacy Policy — OmSai Jents Parlor Dharashiv

Effective date: 29 September 2026

This app is intended for salon customer management.

Data stored:
- Customer name
- Customer mobile number

In the current project, this information is stored locally on the Android device using the app's local storage. The app does not include advertising or analytics SDKs.

Data sharing:
The current project does not send customer data to a third-party server.

User control:
The salon operator can delete customer records from the app.

Contact:
OmSai Jents Parlor Dharashiv
Dharashiv, Maharashtra, India

Before publishing, replace the contact details above with the real business contact information and host this privacy policy at a publicly accessible HTTPS webpage. The Play Console Data safety form must match the final app's actual behavior.
