OmSai Jents Parlor Dharashiv Android app project.
Features: customer add, mobile number, customer list, delete.
Open in Android Studio and build APK.
